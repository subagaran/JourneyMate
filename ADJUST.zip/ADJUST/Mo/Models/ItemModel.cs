﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMauiApp.Models
{
    public class ItemModel

    {
        [PrimaryKey]
        public int ItemId { get; set; }
        public string ItemName { get; set; }      // must match API
        public string Description { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal StockQty { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
