﻿using Microsoft.EntityFrameworkCore;
using StockApi.Data;
using StockApi.Repository;
using StockApi;

var builder = WebApplication.CreateBuilder(args);

// ----------------------
// 🔹 WINDOWS SERVICE SUPPORT
// ----------------------
builder.Host.UseWindowsService();

// ----------------------
// 🔹 DATABASE (SQL SERVER)
// ----------------------
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// ----------------------
// 🔹 DEPENDENCY INJECTION
// ----------------------
builder.Services.AddScoped<IStockRepository, StockRepository>();
builder.Services.AddScoped<IStockService, StockService>();

// ----------------------
// 🔹 CONTROLLERS & SWAGGER
// ----------------------
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ----------------------
// 🔹 SET API URL FOR MOBILE
// ----------------------
builder.WebHost.UseUrls("http://0.0.0.0:5000"); // listen on all network interfaces

var app = builder.Build();

// ----------------------
// 🔹 MIDDLEWARE PIPELINE
// ----------------------

// Global exception handler
app.UseMiddleware<ExceptionMiddleware>();

// API Key middleware
app.UseMiddleware<ApiKeyMiddleware>();

// Swagger only in development
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Optional HTTPS redirection (can disable for local testing)
app.UseHttpsRedirection();

// Authorization (future use)
app.UseAuthorization();

// Map controllers
app.MapControllers();

// ----------------------
// 🔹 RUN THE APP
// ----------------------
app.Run();