﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMauiApp.Models
{
    public class StockAdjustmentModel
    {
        public int ItemId { get; set; }
        public decimal Quantity { get; set; }
        public string Type { get; set; }
        public string Remark { get; set; }
        public string User { get; set; }
    }
}
