﻿public class SyncService
{
    private readonly ApiService _api;
    private readonly LocalDbService _db;

    public SyncService()
    {
        _api = new ApiService();
        _db = new LocalDbService();
    }

    public async Task FirstTimeSync(IProgress<string> progress = null)
    {
        await _db.Init();

        int page = 1;
        int pageSize = 500; // adjust based on performance
        int totalInserted = 0;

        while (true)
        {
            progress?.Report($"Syncing page {page}...");

            var items = await _api.GetItemsAsync(page, pageSize);

            if (items == null || items.Count == 0)
                break;

            await _db.SaveItemsAsync(items);

            totalInserted += items.Count;

            progress?.Report($"Inserted {totalInserted} items...");

            page++;
        }

        // Save last sync time
        await SecureStorage.SetAsync("lastSync", DateTime.UtcNow.ToString());

        progress?.Report("Sync completed!");
    }
}