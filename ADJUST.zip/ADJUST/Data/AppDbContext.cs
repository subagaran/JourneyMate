﻿using Microsoft.EntityFrameworkCore;
using StockApi.Dto;
using StockApi.Model;

namespace StockApi.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Item> Items { get; set; }
        public DbSet<StockAdjustment> StockAdjustment { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Explicitly define primary key (optional if using convention)
            modelBuilder.Entity<StockAdjustment>()
                        .HasKey(sa => sa.StockAdjustmentId);
        }
    }
}
