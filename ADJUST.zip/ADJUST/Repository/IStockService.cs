﻿using StockApi.Dto;
using StockApi.Model;

namespace StockApi.Repository
{
    public interface IStockService
    {
        Task<List<Item>> GetItemsAsync();
        Task<List<Item>> GetItemsAsync(int page, int pageSize);
        Task<bool> AdjustStockAsync(StockAdjustmentDto dto);
    }
}
