﻿using StockApi.Dto;
using StockApi.Model;

namespace StockApi.Repository
{
    public class StockService : IStockService
    {
        private readonly IStockRepository _repo;

        public StockService(IStockRepository repo)
        {
            _repo = repo;
        }



        public async Task<List<Item>> GetItemsAsync()
        {
            var items = await _repo.GetItemsAsync();

            return items.Select(x => new Item
            {
                ItemId = x.ItemId,
                ItemName = x.ItemName,
                StockQty = x.StockQty,
                UnitPrice = x.UnitPrice
            }).ToList();
        }

        // Pagination support
        public async Task<List<Item>> GetItemsAsync(int page, int pageSize)
        {
            return await _repo.GetItemsAsync(page, pageSize);
        }


        public async Task<bool> AdjustStockAsync(StockAdjustmentDto dto)
        {
            var item = await _repo.GetItemByIdAsync(dto.ItemId);

            if (item == null)
                throw new Exception("Item not found");

            // 🔹 Update stock
            if (dto.Type == "ADD")
            {
                item.StockQty += dto.Quantity;
            }
            else if (dto.Type == "REMOVE")
            {
                if (item.StockQty < dto.Quantity)
                    throw new Exception("Insufficient stock");

                item.StockQty -= dto.Quantity;
            }
            else
            {
                throw new Exception("Invalid adjustment type");
            }

            // 🔹 Save item
            await _repo.UpdateItemAsync(item);

            // 🔹 Save history
            var adjustment = new StockAdjustment
            {
                ItemId = dto.ItemId,
                AdjustedQty = dto.Quantity,
                AdjustmentType = dto.Type,
                Remark = dto.Remark,
                AdjustedBy = dto.User,
                AdjustedAt = DateTime.Now
            };

            await _repo.AddAdjustmentAsync(adjustment);

            return true;
        }
    }
}
