﻿namespace StockApi
{
    public class ApiKeyMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _config;

        public ApiKeyMiddleware(RequestDelegate next, IConfiguration config)
        {
            _next = next;
            _config = config;
        }


        public async Task InvokeAsync(HttpContext context, IConfiguration config)
        {
            const string APIKEYNAME = "API-KEY";

            // 🔹 Try header first
            context.Request.Headers.TryGetValue(APIKEYNAME, out var extractedApiKey);

            // 🔹 If not in header, check query string (temporary for testing)
            if (string.IsNullOrEmpty(extractedApiKey))
            {
                extractedApiKey = context.Request.Query[APIKEYNAME];
            }

            if (string.IsNullOrEmpty(extractedApiKey))
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsync("API Key missing");
                return;
            }

            var apiKey = config.GetValue<string>("Security:ApiKey");

            if (!apiKey.Equals(extractedApiKey))
            {
                context.Response.StatusCode = 403;
                await context.Response.WriteAsync("Invalid API Key");
                return;
            }

            await _next(context);
        }
        //public async Task Invoke(HttpContext context)
        //{
        //    if (!context.Request.Headers.TryGetValue("API-KEY", out var key))
        //    {
        //        context.Response.StatusCode = 401;
        //        await context.Response.WriteAsync("API Key missing");
        //        return;
        //    }

        //    if (key != _config["Security:ApiKey"])
        //    {
        //        context.Response.StatusCode = 401;
        //        await context.Response.WriteAsync("Unauthorized");
        //        return;
        //    }

        //    await _next(context);
        //}
    }
}
