﻿using Microsoft.EntityFrameworkCore;
using StockApi.Data;
using StockApi.Dto;
using StockApi.Model;

namespace StockApi.Repository
{ 
    public class StockRepository : IStockRepository
    {
        private readonly AppDbContext _context;

        public StockRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Item>> GetItemsAsync()
        {
            return await _context.Items.AsNoTracking().ToListAsync();
        }
        // Pagination support

        // Pagination
        public async Task<List<Item>> GetItemsAsync(int page, int pageSize)
        {
            var skip = (page - 1) * pageSize;

            return await _context.Items
                .AsNoTracking()
                .OrderBy(x => x.ItemId)
                .Skip(skip)
                .Take(pageSize)
                .Select(x => new Item
                {
                    ItemId = x.ItemId,
                    ItemName = x.ItemName,
                    StockQty = x.StockQty,
                    UnitPrice = x.UnitPrice
                })
                .ToListAsync();
        }
        public async Task<Item> GetItemByIdAsync(int itemId)
        {
            return await _context.Items.FirstOrDefaultAsync(x => x.ItemId == itemId);
        }

        public async Task UpdateItemAsync(Item item)
        {
            _context.Items.Update(item);
            await _context.SaveChangesAsync();
        }

        public async Task AddAdjustmentAsync(StockAdjustment adjustment)
        {
            await _context.StockAdjustment.AddAsync(adjustment);
            await _context.SaveChangesAsync();
        }
    }
}
