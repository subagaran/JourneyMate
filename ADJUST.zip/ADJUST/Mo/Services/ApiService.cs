﻿using StockMauiApp.Models;
using System.Text;
using System.Text.Json;

public class ApiService
{
    private readonly HttpClient _client;

    public ApiService()
    {
        _client = new HttpClient
        {
            BaseAddress = new Uri("http://192.168.1.102:5000/")
        };

        _client.DefaultRequestHeaders.Add("API-KEY", "123456");
    }

    // 🔹 GET ITEMS
    public async Task<List<ItemModel>> GetItemsAsync()
    {
        var response = await _client.GetAsync("api/stock/items");

        if (!response.IsSuccessStatusCode)
            return new List<ItemModel>();

        var json = await response.Content.ReadAsStringAsync();

        return JsonSerializer.Deserialize<List<ItemModel>>(json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }

    public async Task<List<ItemModel>> GetItemsAsync(int page, int pageSize)
    {
        var response = await _client.GetAsync($"api/stock/items?page={page}&pageSize={pageSize}");

        if (!response.IsSuccessStatusCode)
            return new List<ItemModel>();

        var json = await response.Content.ReadAsStringAsync();

        return JsonSerializer.Deserialize<List<ItemModel>>(json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }
    // 🔹 ADJUST STOCK
    public async Task<bool> AdjustStockAsync(StockAdjustmentModel model)
    {
        var json = JsonSerializer.Serialize(model);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _client.PostAsync("api/stock/adjust", content);

        return response.IsSuccessStatusCode;
    }
}