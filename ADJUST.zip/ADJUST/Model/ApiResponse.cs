﻿namespace StockApi.Model
{
    public class ApiResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }

        public static ApiResponse success(string msg) =>
            new ApiResponse { Success = true, Message = msg };

        public static ApiResponse Fail(string msg) =>
            new ApiResponse { Success = false, Message = msg };
    }
}
