﻿namespace StockApi.Model
{
    public class StockAdjustment
    {
        public int StockAdjustmentId { get; set; }   // ✅ Primary key
        public int ItemId { get; set; }
        public decimal AdjustedQty { get; set; }
        public string AdjustmentType { get; set; }
        public string Remark { get; set; }
        public string AdjustedBy { get; set; }
        public DateTime AdjustedAt { get; set; }
    }
}
