﻿using StockMauiApp;
using StockMauiApp.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

public class StockViewModel : INotifyPropertyChanged
{
    private const int PageSize = 500;
    private int currentPage = 0;
    private bool isLoading = false;

    public ObservableCollection<ItemModel> Items { get; set; } = new();

    private ItemModel _selectedItem;
    public ItemModel SelectedItem
    {
        get => _selectedItem;
        set { _selectedItem = value; OnPropertyChanged(); }
    }

    private string _statusMessage;
    public string StatusMessage
    {
        get => _statusMessage;
        set { _statusMessage = value; OnPropertyChanged(); }
    }

    private string _searchText;
    public string SearchText
    {
        get => _searchText;
        set
        {
            _searchText = value;
            OnPropertyChanged();
        }
    }

    public Command SearchCommand { get; }

    private readonly ApiService _api;

    public Command LoadLocalCommand { get; }
    public Command SyncCommand { get; }
    public Command<ItemModel> ItemTappedCommand { get; }
    public Command LoadMoreItemsCommand { get; }

    public StockViewModel()
    {
        _api = new ApiService();

        LoadLocalCommand = new Command(async () => await LoadItemsPaged(reset: true));
        SyncCommand = new Command(async () => await SyncWithCloud());
        LoadMoreItemsCommand = new Command(async () => await LoadItemsPaged());
        ItemTappedCommand = new Command<ItemModel>(async (item) => await AdjustSelectedItem(item));
        SearchCommand = new Command(async () => await SearchItems());
    }
    // Search function with paging
    private async Task SearchItems(bool reset = true)
    {
        if (isLoading) return;
        isLoading = true;

        if (reset)
        {
            currentPage = 0;
            Items.Clear();
        }

        StatusMessage = $"Searching for '{SearchText}'...";

        var db = new LocalDbService();
        await db.Init();

        var list = await db.GetItemsAsync(currentPage * PageSize, PageSize, SearchText);

        foreach (var item in list)
            Items.Add(item);

        currentPage++;
        StatusMessage = $"Found {Items.Count} items";
        isLoading = false;
    }

    // Load items with paging
    private async Task LoadItemsPaged(bool reset = false)
    {
        if (isLoading) return;
        isLoading = true;

        if (reset)
        {
            currentPage = 0;
            Items.Clear();
        }

        StatusMessage = "Loading items...";

        var db = new LocalDbService();
        await db.Init();

        var list = await db.GetItemsAsync(currentPage * PageSize, PageSize);

        foreach (var item in list)
            Items.Add(item);

        currentPage++;
        StatusMessage = $"Loaded {Items.Count} items";
        isLoading = false;
    }

    // Sync with cloud
    private async Task SyncWithCloud()
    {
        var syncService = new SyncService();

        var progress = new Progress<string>(msg =>
        {
            StatusMessage = msg; // update UI
        });

        await syncService.FirstTimeSync(progress);
        StatusMessage = "Cloud sync completed";

        // Optional: reload first page after sync
        await LoadItemsPaged(reset: true);
    }

    // Adjust stock for tapped item
    private async Task AdjustSelectedItem(ItemModel item)
    {
        if (item == null) return;

        string qtyStr = await App.Current.MainPage.DisplayPromptAsync(
            "Adjust Stock",
            $"Enter quantity for {item.ItemName}",
            keyboard: Keyboard.Numeric);

        if (!decimal.TryParse(qtyStr, out decimal qty)) return;

        string action = await App.Current.MainPage.DisplayActionSheet(
            "Select Type", "Cancel", null, "ADD", "REMOVE");

        if (action == "Cancel") return;

        var model = new StockAdjustmentModel
        {
            ItemId = item.ItemId,
            Quantity = qty,
            Type = action,
            Remark = "Mobile adjustment",
            User = "MobileUser"
        };

        bool success = await _api.AdjustStockAsync(model);

        if (success)
            await App.Current.MainPage.DisplayAlert("Success", "Stock updated", "OK");
        else
            await App.Current.MainPage.DisplayAlert("Error", "Failed", "OK");
    }

    public event PropertyChangedEventHandler PropertyChanged;
    void OnPropertyChanged([CallerMemberName] string name = "") =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}