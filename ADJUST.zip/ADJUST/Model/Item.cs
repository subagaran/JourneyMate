﻿namespace StockApi.Model
{
    public class Item
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public decimal StockQty { get; set; }
        public decimal UnitPrice { get; set; }
    }
}
