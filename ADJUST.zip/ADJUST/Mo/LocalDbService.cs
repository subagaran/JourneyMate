﻿using SQLite;
using StockMauiApp.Models;

public class LocalDbService
{
    private SQLiteAsyncConnection _db;

    public async Task Init()
    {
        if (_db != null) return;

        var path = Path.Combine(FileSystem.AppDataDirectory, "stock.db");
        _db = new SQLiteAsyncConnection(path);

        await _db.CreateTableAsync<ItemModel>();
    }

    public async Task SaveItemsAsync(List<ItemModel> items)
    {
        await _db.RunInTransactionAsync(tran =>
        {
            foreach (var item in items)
            {
                tran.InsertOrReplace(item);
            }
        });
    }

    public async Task<List<ItemModel>> GetItemsAsync()
    {
        return await _db.Table<ItemModel>().ToListAsync();
    }

    public async Task<List<ItemModel>> GetItemsAsync(int skip, int take)
    { 
        return await _db.Table<ItemModel>()
                   .Skip(skip)
                   .Take(take)
                   .ToListAsync();
    }

    public async Task<List<ItemModel>> GetItemsAsync(int skip, int take, string search = null)
    { 

        var query = _db.Table<ItemModel>();

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(x => x.ItemName.Contains(search));

        return await query.Skip(skip).Take(take).ToListAsync();
    }
}