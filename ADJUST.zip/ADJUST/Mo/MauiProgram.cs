﻿using Microsoft.Extensions.Logging;

namespace StockMauiApp
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

#if DEBUG
    		builder.Logging.AddDebug();
#endif

            builder.Services.AddSingleton<ApiService>();
            builder.Services.AddSingleton<LocalDbService>();
            builder.Services.AddSingleton<SyncService>();


            builder.Services.AddTransient<StockViewModel>();

            // --- Register pages ---
            builder.Services.AddTransient<Views.MainPage>();

            return builder.Build();
        }
    }
}
