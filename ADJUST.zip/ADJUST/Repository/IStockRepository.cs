﻿using StockApi.Dto;
using StockApi.Model;

namespace StockApi.Repository
{
    public interface IStockRepository
    {
        Task<List<Item>> GetItemsAsync();

        Task<List<Item>> GetItemsAsync(int page, int pageSize);
        Task<Item> GetItemByIdAsync(int itemId);
        Task UpdateItemAsync(Item item);
        Task AddAdjustmentAsync(StockAdjustment adjustment);
    }
}
