﻿namespace StockApi.Dto
{
    public class StockAdjustmentDto
    {
        public int ItemId { get; set; }
        public decimal Quantity { get; set; }
        public string Type { get; set; } // ADD / REMOVE
        public string Remark { get; set; }
        public string User { get; set; }
    }
}
