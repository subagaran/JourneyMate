﻿using Microsoft.AspNetCore.Mvc;
using StockApi.Dto;
using StockApi.Model;
using StockApi.Repository;

namespace StockApi.Controllers
{
    using Microsoft.AspNetCore.Mvc;

    [ApiController]
    [Route("api/[controller]")]
    public class StockController : ControllerBase
    {
        private readonly IStockService _service;

        public StockController(IStockService service)
        {
            _service = service;
        }

        // 🔹 GET ITEMS (SYNC TO MOBILE)
        //[HttpGet("items")]
        //public async Task<IActionResult> GetItems()
        //{
        //    var data = await _service.GetItemsAsync();
        //    return Ok(data);
        //}

        // 🔹 GET ITEMS WITH PAGINATION
        [HttpGet("items")]
        public async Task<IActionResult> GetItems([FromQuery] int page = 1, [FromQuery] int pageSize = 500)
        {
            if (page <= 0) page = 1;
            if (pageSize <= 0) pageSize = 500;

            var data = await _service.GetItemsAsync(page, pageSize);

            return Ok(data);
        }


        // 🔹 ADJUST STOCK
        [HttpPost("adjust")]
        public async Task<IActionResult> AdjustStock([FromBody] StockAdjustmentDto dto)
        {
            try
            {
                await _service.AdjustStockAsync(dto);
                return Ok(new { message = "Stock updated successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

    //    [HttpGet("adjust")]
    //    public async Task<IActionResult> AdjustStockViaQuery(
    //int ItemId, decimal Quantity, string Type, string Remark, string User)
    //    {
    //        try
    //        {
    //            var dto = new StockAdjustmentDto
    //            {
    //                ItemId = ItemId,
    //                Quantity = Quantity,
    //                Type = Type,
    //                Remark = Remark,
    //                User = User
    //            };

    //            await _service.AdjustStockAsync(dto);

    //            return Ok(new { message = "Stock updated successfully" });
    //        }
    //        catch (Exception ex)
    //        {
    //            return BadRequest(new { error = ex.Message });
    //        }
    //    }
    }
}
